import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CartItem } from './cart-item.entity';
import { User } from '../auth/user.entity';
import { Product } from '../product/product.entity';

@Injectable()
export class CartService {
  constructor(
    @InjectRepository(CartItem)
    private cartRepo: Repository<CartItem>,
    @InjectRepository(User) private userRepo: Repository<User>,
    @InjectRepository(Product) private productRepo: Repository<Product>,
  ) {}

  async addToCart(userId: number, productId: number, quantity: number) {
    if (quantity <= 0) {
      throw new BadRequestException('Quantity must be at least 1');
    }
  
    // Fetch User and Product entities first
    const user = await this.userRepo.findOne({ where: { id: userId } });
    const product = await this.productRepo.findOne({ where: { id: productId } });
  
    if (!user) {
      throw new NotFoundException('User not found');
    }
    if (!product) {
      throw new NotFoundException('Product not found');
    }
  
    // Corrected way to check if cart item exists
    const existingItem = await this.cartRepo
      .createQueryBuilder('cart')
      .where('cart.userId = :userId', { userId })
      .andWhere('cart.productId = :productId', { productId })
      .getOne();
  
    if (existingItem) {
      existingItem.quantity += quantity;
      return this.cartRepo.save(existingItem);
    }
  
    // Create new cart item with correct entity references
    const cartItem = this.cartRepo.create({ user, product, quantity });
    return this.cartRepo.save(cartItem);
  }
  
//   async getCartItems(userId: number) {
//     const user = await this.userRepo.findOne({ where: { id: userId } });
  
//     if (!user) {
//       throw new NotFoundException('User not found');
//     }
  
//     return this.cartRepo.find({
//       where: { user },
//       relations: ['product'],
//     });
//   }
  
  async getCartItems(userId: number) {
    return this.cartRepo.find({
      where: { user: { id: userId } },
      relations: ['product'],
    });
  }

  async updateCartItem(cartId: number, quantity: number) {
    if (quantity <= 0) {
      throw new BadRequestException('Quantity must be at least 1');
    }

    const cartItem = await this.cartRepo.findOne({ where: { id: cartId } });
    if (!cartItem) throw new NotFoundException('Cart item not found');

    cartItem.quantity = quantity;
    return this.cartRepo.save(cartItem);
  }

  async removeCartItem(cartId: number) {
    const cartItem = await this.cartRepo.findOne({ where: { id: cartId } });
    if (!cartItem) throw new NotFoundException('Cart item not found');

    return this.cartRepo.delete(cartId);
  }

  async clearCart(userId: number) {
    return this.cartRepo.delete({ user: { id: userId } });
  }
}
