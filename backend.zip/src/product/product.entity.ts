import { Entity, Column, PrimaryGeneratedColumn,CreateDateColumn  } from 'typeorm';
import { IsNotEmpty, IsPositive, IsOptional } from 'class-validator';

@Entity()
export class Product {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  @IsNotEmpty()
  name: string;

  @Column('float')
  @IsPositive()
  price: number;

  @Column()
  stock: number;

  @Column({ nullable: true })
  @IsOptional()
  description?: string;

  @Column('text', { array: true })
  images: string[];

  @CreateDateColumn({ type: 'timestamp' })
  createdAt: Date;
}
